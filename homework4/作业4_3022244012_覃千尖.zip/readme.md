第四章  数值积分

1.源代码：NumericalIntegration.py
        运行 python NumericalIntegration.py 
2.批量测试脚本： test.py 
        运行 python test.py, 结果输出在 integration_results.txt
3.输出文件： integration_results.txt